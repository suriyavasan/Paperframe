--
project name: `Paperframe`,
author: `Suriyanarayanan R Srinivasan`,
version: 1.0,
author_url: `https://suriyanarayanan.co.in`
description: `Printable AR/VR ideation Sketchpad`,
siteUrl: `https://paperframe.co`,
license: "CC - Free for both personal and commercial use"
--

Crafting Experience for the VR/AR/MR is not about working on a Machine always, People love to sketch their ideas on paper. That helps to Speed up your creative Process. Just choose the template according to your need, print it out and start sketching your dream project. Happy Designing!

Thanks you for downloading
✌️
